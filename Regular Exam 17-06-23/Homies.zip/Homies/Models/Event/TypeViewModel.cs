﻿namespace Homies.Models.Event
{
    public class TypeViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; } = null!;
    }
}
