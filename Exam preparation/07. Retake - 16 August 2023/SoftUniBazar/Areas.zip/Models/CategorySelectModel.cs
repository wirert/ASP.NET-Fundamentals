﻿namespace SoftUniBazar.Models
{
    public class CategorySelectModel
    {
        public int Id { get; set; }

        public string Name { get; set; } = null!;
    }
}
